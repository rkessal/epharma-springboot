package hn.epharma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpharmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
